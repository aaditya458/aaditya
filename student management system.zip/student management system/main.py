# main.py
import os
import time
from student import Student
from admin import Admin
from utils import load_data, save_data, clear_screen

def display_welcome():
    """Creative welcome screen"""
    clear_screen()
    print(r"""
  ____  _       _     _     ____   ___   ___    _    ____ _____ 
 | __ )| | ___ | |__ | |_  |___ \ / _ \ / _ \  / \  / ___|_   _|
 |  _ \| |/ _ \| '_ \| __|   __) | | | | | | |/ _ \| |     | |  
 | |_) | | (_) | | | | |_   / __/| |_| | |_| / ___ \ |___  | |  
 |____/|_|\___/|_| |_|\__| |_____|\___/ \___/_/   \_\____| |_|  
                                                                
    """)
    print("\nBritish College, Thapathali - Student Profile System")
    print("Developed for BSc AI Program\n")
    time.sleep(1)

def initialize_files():
    """Ensure all required data files exist with headers"""
    files = {
        'users.txt': 'ID,Name,Email,Role,Contact,Program\n',
        'grades.txt': 'ID,Programming,Mathematics,AI Fundamentals,Database,Statistics\n',
        'eca.txt': 'ID,Activity,Role,Hours,Semester\n',
        'passwords.txt': 'username,password\n'
    }
    
    if not os.path.exists('data'):
        os.makedirs('data')
    
    for filename, header in files.items():
        if not os.path.exists(f'data/{filename}'):
            with open(f'data/{filename}', 'w') as f:
                f.write(header)

def login():
    """Handle user login with creative elements"""
    passwords = load_data('passwords.txt')
    attempts = 0
    
    while True:
        clear_screen()
        print("=== British College Login ===")
        print("Please enter your credentials:")
        
        # Show college mascot after 2 failed attempts
        if attempts >= 2:
            print(r"""
              .-""-.
             / .--. \
            / /    \ \
            | |    | |
            | |.-""-.|
           ///`.::::.`\
          ||| ::/  \:: ;
          ||; ::\__/:: ;
           \\\ '::::' /
            `=':-..-'`
            """)
            print("Need help? Contact IT at ithelp@british.edu.np\n")
        
        username = input("College Email: ").strip().lower()
        password = input("Password: ").strip()
        
        for record in passwords:
            if record['username'] == username and record['password'] == password:
                users = load_data('users.txt')
                for user in users:
                    if user['Email'].lower() == username:
                        print(f"\nWelcome, {user['Name']}!")
                        time.sleep(1)
                        return user['ID'], user['Role']
        
        attempts += 1
        print("\nInvalid credentials. Please try again.")
        time.sleep(1)

def main():
    display_welcome()
    initialize_files()
    
    while True:
        user_id, role = login()
        
        if role == 'admin':
            admin = Admin(user_id)
            admin.admin_menu()
        elif role == 'student':
            student = Student(user_id)
            student.student_menu()
        else:
            print("Unknown role. Please contact system administrator.")
            break

if __name__ == "__main__":
    main()