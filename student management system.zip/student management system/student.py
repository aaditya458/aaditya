# student.py
from utils import load_data, save_data, clear_screen
import time

class Student:
    def __init__(self, student_id):
        self.student_id = student_id
        self.user_data = self._get_user_data()
    
    def _get_user_data(self):
        users = load_data('users.txt')
        for user in users:
            if user['ID'] == self.student_id:
                return user
        return None
    
    def display_student_banner(self):
        print(f"\nBritish College - {self.user_data['Program']}")
        print(f"Student Portal: {self.user_data['Name']}")
        print("=" * 40)
    
    def student_menu(self):
        while True:
            clear_screen()
            self.display_student_banner()
            print("\nMAIN MENU")
            print("1. 📝 View My Profile")
            print("2. 📊 View My Grades")
            print("3. ⚽ View My ECAs")
            print("4. ✏️ Update Profile")
            print("5. 🏆 View Academic Standing")
            print("6. 🚪 Logout")
            
            choice = input("\nEnter your choice: ")
            
            if choice == '1':
                self.view_profile()
            elif choice == '2':
                self.view_grades()
            elif choice == '3':
                self.view_eca()
            elif choice == '4':
                self.update_profile()
            elif choice == '5':
                self.view_academic_standing()
            elif choice == '6':
                print("\nLogging out...")
                time.sleep(1)
                break
            else:
                print("Invalid choice. Please try again.")
                time.sleep(1)
    
    def view_profile(self):
        clear_screen()
        self.display_student_banner()
        print("\n🧑‍🎓 STUDENT PROFILE")
        print(f"Name: {self.user_data['Name']}")
        print(f"Program: {self.user_data['Program']}")
        print(f"Email: {self.user_data['Email']}")
        print(f"Contact: {self.user_data['Contact']}")
        
        # Add some creative elements
        print("\n📅 Current Semester: Spring 2025")
        print("🏛️ Campus: Thapathali")
        print("📚 Library ID: BC-{}-{}".format(self.student_id[-3:], 
                                             self.user_data['Name'][0:2].upper()))
        
        input("\nPress Enter to return to menu...")
    
    def view_grades(self):
        clear_screen()
        self.display_student_banner()
        grades = load_data('grades.txt')
        student_grades = None
        
        for record in grades:
            if record['ID'] == self.student_id:
                student_grades = record
                break
        
        if student_grades:
            print("\n📊 ACADEMIC PERFORMANCE")
            print("\nSubject\t\t\tGrade")
            print("-" * 30)
            for subject, score in student_grades.items():
                if subject != 'ID':
                    print(f"{subject:<20}\t{score}")
            
            # Calculate average with creative feedback
            total = sum(int(score) for subject, score in student_grades.items() 
                       if subject != 'ID')
            average = total / (len(student_grades) - 1)
            
            print("\n" + "=" * 30)
            print(f"Overall Average: {average:.2f}")
            
            # Add motivational message based on performance
            if average >= 85:
                print("\n🌟 Excellent performance! Keep up the good work!")
            elif average >= 70:
                print("\n👍 Good work! You're on the right track.")
            else:
                print("\n💪 You can do better! Visit the academic support center.")
            
            print("\nNext term begins: 15 May 2025")
        else:
            print("\nNo grades found for this student.")
        
        input("\nPress Enter to return to menu...")
    
    def view_eca(self):
        clear_screen()
        self.display_student_banner()
        eca_records = load_data('eca.txt')
        student_ecas = [rec for rec in eca_records if rec['ID'] == self.student_id]
        
        if student_ecas:
            print("\n⚽ EXTRACURRICULAR ACTIVITIES")
            total_hours = 0
            for eca in student_ecas:
                print(f"\nActivity: {eca['Activity']}")
                print(f"Role: {eca['Role']}")
                print(f"Hours: {eca['Hours']}")
                print(f"Semester: {eca['Semester']}")
                total_hours += int(eca['Hours'])
            
            print("\n" + "=" * 30)
            print(f"Total ECA Hours: {total_hours}")
            
            # Creative feedback based on involvement
            if total_hours > 25:
                print("\n🏆 You're very active! Great campus involvement!")
            elif total_hours > 15:
                print("\n👍 Good balance between academics and activities")
            else:
                print("\nℹ️ Consider joining more activities to enrich your experience")
            
            # Announce upcoming events
            print("\nUpcoming Events:")
            print("- Sports Day: 25 April 2025")
            print("- Tech Fest: 10 May 2025")
        else:
            print("\nNo ECA records found for this student.")
            print("\nWhy not join a club? Visit Student Affairs office!")
        
        input("\nPress Enter to return to menu...")
    
    def update_profile(self):
        clear_screen()
        self.display_student_banner()
        print("\n✏️ UPDATE PROFILE")
        print("\nCurrent Information:")
        print(f"1. Name: {self.user_data['Name']}")
        print(f"2. Email: {self.user_data['Email']}")
        print(f"3. Contact: {self.user_data['Contact']}")
        
        field_map = {
            '1': 'Name',
            '2': 'Email',
            '3': 'Contact'
        }
        
        choice = input("\nEnter number of field to update (or '0' to cancel): ")
        
        if choice == '0':
            return
        elif choice in field_map:
            field = field_map[choice]
            new_value = input(f"Enter new {field}: ").strip()
            
            # Update in memory
            self.user_data[field] = new_value
            
            # Update in file
            users = load_data('users.txt')
            for user in users:
                if user['ID'] == self.student_id:
                    user[field] = new_value
                    break
            
            save_data('users.txt', users)
            print("\nProfile updated successfully!")
            
            # Special message for contact number change
            if field == 'Contact':
                print("\nℹ️ Emergency contacts updated in college records.")
        else:
            print("Invalid choice.")
        
        time.sleep(1)
    
    def view_academic_standing(self):
        clear_screen()
        self.display_student_banner()
        print("\n🏆 ACADEMIC STANDING")
        
        grades = load_data('grades.txt')
        student_grades = None
        
        for record in grades:
            if record['ID'] == self.student_id:
                student_grades = record
                break
        
        if student_grades:
            # Calculate average
            total = sum(int(score) for subject, score in student_grades.items() 
                       if subject != 'ID')
            average = total / (len(student_grades) - 1)
            
            # Determine standing
            if average >= 85:
                standing = "First Class with Distinction"
                advice = "Eligible for honors program and scholarships"
            elif average >= 70:
                standing = "First Class"
                advice = "Maintain your performance for graduate opportunities"
            elif average >= 60:
                standing = "Second Class"
                advice = "Consider academic support to reach first class"
            elif average >= 50:
                standing = "Pass"
                advice = "Visit your academic advisor for improvement strategies"
            else:
                standing = "Conditional Pass"
                advice = "Mandatory meeting with academic advisor required"
            
            print(f"\nCurrent Standing: {standing}")
            print(f"Average Score: {average:.2f}")
            print(f"\nAdvisor Note: {advice}")
            
            # Add creative progress bar
            print("\nProgress to Next Level:")
            progress = min(100, (average / 85) * 100) if average < 85 else 100
            print(f"[{'=' * int(progress//5)}{' ' * (20 - int(progress//5))}] {progress:.1f}%")
            
            if average < 85:
                needed = 85 - average
                print(f"\nYou need {needed:.2f} more points average for distinction")
        else:
            print("\nNo academic records available yet.")
        
        input("\nPress Enter to return to menu...")