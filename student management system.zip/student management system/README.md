# Student Profile Management System

### Author: Aaditya Rauniyar  
### Student ID: 24071212  
### Course: BSc AI Level 3  
### Module: Fundamentals of Data Science

---

## 📌 Project Description

This project is a terminal-based **Student Profile Management System** developed in Python. It allows administrators to manage student information, grades, and extracurricular activities (ECA), and provides role-based access for both admin and student users.

---

## ✅ Features

### 🔐 Login System
- Role-based login (Admin / Student)
- Credential validation using `passwords.txt`

### 👨‍💼 Admin Functionalities
- Add, edit, delete student profiles
- Manage grades and ECA records
- View analytics (average grades, top ECA performer)

### 🎓 Student Functionalities
- View and update personal profile
- View grades, ECA, academic standing
- Motivational feedback and performance suggestions

---

## 📂 Folder Structure

```
student-management-system/
│
├── main.py
├── admin.py
├── student.py
├── utils.py
│
├── data/
│   ├── users.txt
│   ├── grades.txt
│   ├── eca.txt
│   └── passwords.txt
│
├── screenshots/
│   ├── admin_dashboard.png
│   ├── student_profile.png
│   └── student_grades.png
│
├── docs/
│   ├── Student_Profile_Report_Outline.docx
│   ├── Student_Profile_Presentation.pptx
│   └── flowchart.png
│
└── README.md
```

---

## 🚀 How to Run

1. Ensure Python 3 is installed.
2. Open terminal or command prompt.
3. Navigate to the project folder.
4. Run the project:
```
python main.py
```

---

## 📦 Requirements

The system uses only built-in Python libraries, so no external packages are required.  
If needed, install PIL for screenshots:

```
pip install pillow
```

---

## 🧠 Learning Outcomes

- Mastery of Object-Oriented Programming in Python
- Practical experience with file handling (CSV)
- Creative CLI design and analytics
- Role-based access control

---

## 📧 Contact

For any queries: aaditya.rauniyar@british.edu.np