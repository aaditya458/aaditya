# admin.py
from utils import load_data, save_data, clear_screen
import time

class Admin:
    def __init__(self, admin_id):
        self.admin_id = admin_id
        self.user_data = self._get_user_data()
    
    def _get_user_data(self):
        users = load_data('users.txt')
        for user in users:
            if user['ID'] == self.admin_id:
                return user
        return None
    
    def display_admin_banner(self):
        print(f"\nBritish College - Administration Portal")
        print(f"Logged in as: {self.user_data['Name']}")
        print("=" * 40)
    
    def admin_menu(self):
        while True:
            clear_screen()
            self.display_admin_banner()
            print("\nADMIN MENU")
            print("1. 👥 Manage Students")
            print("2. 📊 View Analytics")
            print("3. 📝 Update System Data")
            print("4. 🚪 Logout")
            
            choice = input("\nEnter your choice: ")
            
            if choice == '1':
                self.manage_students()
            elif choice == '2':
                self.view_analytics()
            elif choice == '3':
                self.update_system_data()
            elif choice == '4':
                print("\nLogging out...")
                time.sleep(1)
                break
            else:
                print("Invalid choice. Please try again.")
                time.sleep(1)
    
    def manage_students(self):
        clear_screen()
        self.display_admin_banner()
        print("\n👥 STUDENT MANAGEMENT")
        print("1. Add New Student")
        print("2. Edit Student Record")
        print("3. Delete Student")
        print("4. View All Students")
        print("5. Back to Main Menu")
        
        choice = input("\nEnter your choice: ")
        
        if choice == '1':
            self.add_student()
        elif choice == '2':
            self.edit_student()
        elif choice == '3':
            self.delete_student()
        elif choice == '4':
            self.view_all_students()
        elif choice == '5':
            return
        else:
            print("Invalid choice.")
            time.sleep(1)
    
    def add_student(self):
        clear_screen()
        self.display_admin_banner()
        print("\n➕ ADD NEW STUDENT")
        
        # Generate new student ID
        users = load_data('users.txt')
        last_id = max(int(user['ID'][1:]) for user in users if user['ID'].startswith('S')) if any(user['ID'].startswith('S') for user in users) else 0
        new_id = f"S{last_id + 1:03d}"
        
        name = input("Full Name: ")
        email = input("Email: ")
        contact = input("Contact: ")
        program = input("Program (e.g., BSc AI): ")
        password = input("Set Temporary Password: ")
        
        # Add to users.txt
        new_user = {
            'ID': new_id,
            'Name': name,
            'Email': email,
            'Role': 'student',
            'Contact': contact,
            'Program': program
        }
        users.append(new_user)
        save_data('users.txt', users)
        
        # Add to passwords.txt
        passwords = load_data('passwords.txt')
        passwords.append({
            'username': email,
            'password': password
        })
        save_data('passwords.txt', passwords)
        
        # Initialize empty records in grades.txt and eca.txt
        grades = load_data('grades.txt')
        grades.append({
            'ID': new_id,
            'Programming': '0',
            'Mathematics': '0',
            'AI Fundamentals': '0',
            'Database': '0',
            'Statistics': '0'
        })
        save_data('grades.txt', grades)
        
        print(f"\n✅ Student {name} added successfully with ID: {new_id}")
        time.sleep(2)
    
    def edit_student(self):
        clear_screen()
        self.display_admin_banner()
        print("\n✏️ EDIT STUDENT RECORD")
        
        student_id = input("Enter Student ID to edit (e.g., S001): ").upper()
        users = load_data('users.txt')
        student = None
        
        for user in users:
            if user['ID'] == student_id and user['Role'] == 'student':
                student = user
                break
        
        if not student:
            print("\n❌ Student not found!")
            time.sleep(1)
            return
        
        print("\nCurrent Information:")
        for key, value in student.items():
            print(f"{key}: {value}")
        
        field = input("\nEnter field to edit (Name/Email/Contact/Program): ").capitalize()
        if field not in ['Name', 'Email', 'Contact', 'Program']:
            print("Invalid field!")
            time.sleep(1)
            return
        
        new_value = input(f"Enter new {field}: ")
        student[field] = new_value
        save_data('users.txt', users)
        
        # Update password if email changed
        if field == 'Email':
            passwords = load_data('passwords.txt')
            for record in passwords:
                if record['username'] == student['Email']:
                    record['username'] = new_value
                    break
            save_data('passwords.txt', passwords)
        
        print("\n✅ Record updated successfully!")
        time.sleep(1)
    
    def delete_student(self):
        clear_screen()
        self.display_admin_banner()
        print("\n❌ DELETE STUDENT RECORD")
        
        student_id = input("Enter Student ID to delete (e.g., S001): ").upper()
        users = load_data('users.txt')
        student = None
        
        for user in users:
            if user['ID'] == student_id and user['Role'] == 'student':
                student = user
                break
        
        if not student:
            print("\n❌ Student not found!")
            time.sleep(1)
            return
        
        print(f"\nAre you sure you want to delete {student['Name']} ({student_id})?")
        confirm = input("Type 'YES' to confirm: ")
        
        if confirm.upper() != 'YES':
            print("\nDeletion cancelled.")
            time.sleep(1)
            return
        
        # Remove from users.txt
        users = [user for user in users if user['ID'] != student_id]
        save_data('users.txt', users)
        
        # Remove from passwords.txt
        passwords = load_data('passwords.txt')
        passwords = [pwd for pwd in passwords if pwd['username'] != student['Email']]
        save_data('passwords.txt', passwords)
        
        # Remove from grades.txt
        grades = load_data('grades.txt')
        grades = [grade for grade in grades if grade['ID'] != student_id]
        save_data('grades.txt', grades)
        
        # Remove from eca.txt
        eca = load_data('eca.txt')
        eca = [rec for rec in eca if rec['ID'] != student_id]
        save_data('eca.txt', eca)
        
        print("\n✅ Student record deleted successfully!")
        time.sleep(1)
    
    def view_all_students(self):
        clear_screen()
        self.display_admin_banner()
        print("\n👥 ALL STUDENT RECORDS")
        
        users = load_data('users.txt')
        students = [user for user in users if user['Role'] == 'student']
        
        if not students:
            print("No student records found.")
            input("\nPress Enter to continue...")
            return
        
        for student in students:
            print("\n" + "=" * 30)
            for key, value in student.items():
                print(f"{key}: {value}")
        
        input("\nPress Enter to continue...")
    
    def view_analytics(self):
        clear_screen()
        self.display_admin_banner()
        print("\n📊 ANALYTICS DASHBOARD")
        
        users = load_data('users.txt')
        grades = load_data('grades.txt')
        eca = load_data('eca.txt')
        
        # Basic stats
        num_students = len([user for user in users if user['Role'] == 'student'])
        num_eca_activities = len(eca)
        
        print(f"\n📌 Total Students: {num_students}")
        print(f"📌 Total ECA Activities: {num_eca_activities}")
        
        # Average grades per subject
        if num_students > 0:
            subjects = ['Programming', 'Mathematics', 'AI Fundamentals', 'Database', 'Statistics']
            print("\n📚 AVERAGE GRADES PER SUBJECT")
            for subject in subjects:
                total = sum(int(grade[subject]) for grade in grades)
                avg = total / num_students
                print(f"{subject}: {avg:.2f}")
        
        # Most active students in ECA
        eca_hours = {}
        for record in eca:
            if record['ID'] not in eca_hours:
                eca_hours[record['ID']] = 0
            eca_hours[record['ID']] += int(record['Hours'])
        
        if eca_hours:
            top_student_id = max(eca_hours, key=eca_hours.get)
            top_student = next(user for user in users if user['ID'] == top_student_id)
            print(f"\n🏆 Most Active Student in ECA: {top_student['Name']} ({eca_hours[top_student_id]} hours)")
        
        input("\nPress Enter to continue...")
    
    def update_system_data(self):
        clear_screen()
        self.display_admin_banner()
        print("\n📝 UPDATE SYSTEM DATA")
        print("1. Update Student Grades")
        print("2. Add ECA Activity")
        print("3. Back to Main Menu")
        
        choice = input("\nEnter your choice: ")
        
        if choice == '1':
            self.update_grades()
        elif choice == '2':
            self.add_eca()
        elif choice == '3':
            return
        else:
            print("Invalid choice.")
            time.sleep(1)
    
    def update_grades(self):
        clear_screen()
        self.display_admin_banner()
        print("\n📝 UPDATE STUDENT GRADES")
        
        student_id = input("Enter Student ID (e.g., S001): ").upper()
        grades = load_data('grades.txt')
        student_grades = None
        
        for grade in grades:
            if grade['ID'] == student_id:
                student_grades = grade
                break
        
        if not student_grades:
            print("\n❌ Student not found in grades records!")
            time.sleep(1)
            return
        
        print("\nCurrent Grades:")
        for subject, score in student_grades.items():
            if subject != 'ID':
                print(f"{subject}: {score}")
        
        subject = input("\nEnter subject to update: ").capitalize()
        if subject not in ['Programming', 'Mathematics', 'AI Fundamentals', 'Database', 'Statistics']:
            print("Invalid subject!")
            time.sleep(1)
            return
        
        new_grade = input(f"Enter new grade for {subject} (0-100): ")
        if not new_grade.isdigit() or int(new_grade) < 0 or int(new_grade) > 100:
            print("Grade must be between 0 and 100!")
            time.sleep(1)
            return
        
        student_grades[subject] = new_grade
        save_data('grades.txt', grades)
        
        print("\n✅ Grades updated successfully!")
        time.sleep(1)
    
    def add_eca(self):
        clear_screen()
        self.display_admin_banner()
        print("\n➕ ADD ECA ACTIVITY")
        
        student_id = input("Enter Student ID (e.g., S001): ").upper()
        users = load_data('users.txt')
        student = None
        
        for user in users:
            if user['ID'] == student_id and user['Role'] == 'student':
                student = user
                break
        
        if not student:
            print("\n❌ Student not found!")
            time.sleep(1)
            return
        
        activity = input("Activity Name: ")
        role = input("Student's Role: ")
        hours = input("Total Hours: ")
        semester = input("Semester (e.g., Spring 2025): ")
        
        eca = load_data('eca.txt')
        eca.append({
            'ID': student_id,
            'Activity': activity,
            'Role': role,
            'Hours': hours,
            'Semester': semester
        })
        save_data('eca.txt', eca)
        
        print("\n✅ ECA activity added successfully!")
        time.sleep(1)