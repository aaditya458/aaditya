# utils.py
import csv
import os

def load_data(filename):
    """Load data from CSV file into list of dictionaries"""
    data = []
    try:
        with open(f'data/{filename}', mode='r') as file:
            reader = csv.DictReader(file)
            for row in reader:
                data.append(row)
    except FileNotFoundError:
        print(f"Warning: {filename} not found. Creating new file.")
        with open(f'data/{filename}', 'w') as file:
            file.write('')
    return data

def save_data(filename, data):
    """Save list of dictionaries to CSV file"""
    if not data:
        return
    
    with open(f'data/{filename}', mode='w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=data[0].keys())
        writer.writeheader()
        writer.writerows(data)

def clear_screen():
    """Clear terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')